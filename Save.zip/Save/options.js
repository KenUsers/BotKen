const { BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType,WaConnection,MessageType,Mimetype } = require("@adiwajshing/baileys");
const { spawn } = require('child_process');
const fs = require("fs");
const util = require("util");
const chalk = require("chalk");
const { BitlyClient } = require('bitly');
const bitly = new BitlyClient('f5415086b0c2958ba1e92bf71e2885be9d779e90', {});
let ownerData = fs.readFileSync('people/owner.json');
const path = require('path');
const axios = require('axios');
let owner = JSON.parse(ownerData);
const { Configuration, OpenAIApi } = require("openai");
let memberData = fs.readFileSync('member.json');
const fileName = 'logo-bot.png';
const filePath = './logo-bot.png';
const fileData = fs.readFileSync(filePath);
const filesName = 'logo-bot.png';
const filesPath = './logo-bot.png';
const filesData = fs.readFileSync(filesPath);
let member = JSON.parse(memberData);
let setting = require("./key.json");
const readline = require('readline');
const open = require('open');
const owners = ["6287777870536"];


module.exports = sansekai = async (client, m, chatUpdate, store) => {
  try {
    async function sendMessage(jid, text) {
  	await client.sendMessage(jid, text, MessageType);
	}
	function generateRandomCode() {
	  const code = Math.floor(Math.random() * 9000) + 1000;
	  return code;
	}


    var body =
      m.mtype === "conversation"
        ? m.message.conversation
        : m.mtype == "imageMessage"
        ? m.message.imageMessage.caption
        : m.mtype == "videoMessage"
        ? m.message.videoMessage.caption
        : m.mtype == "extendedTextMessage"
        ? m.message.extendedTextMessage.text
        : m.mtype == "buttonsResponseMessage"
        ? m.message.buttonsResponseMessage.selectedButtonId
        : m.mtype == "listResponseMessage"
        ? m.message.listResponseMessage.singleSelectReply.selectedRowId
        : m.mtype == "templateButtonReplyMessage"
        ? m.message.templateButtonReplyMessage.selectedId
        : m.mtype === "messageContextInfo"
        ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text
        : "";
    var budy = typeof m.text == "string" ? m.text : "";
    // var prefix = /^[\\/!#.]/gi.test(body) ? body.match(/^[\\/!#.]/gi) : "/"
    var prefix = /^[\\/!#.]/gi.test(body) ? body.match(/^[\\/!#.]/gi) : ".";
    const isCmd2 = body.startsWith(prefix);
    const command = body.replace(prefix, "").trim().split(/ +/).shift().toLowerCase();
    const args = body.trim().split(/ +/).slice(1);
    const pushname = m.pushName || "No Name";
    const botNumber = await client.decodeJid(client.user.id);
    const itsMe = m.sender == botNumber ? true : false;
    let text = (q = args.join(" "));
    const arg = budy.trim().substring(budy.indexOf(" ") + 1);
    const arg1 = arg.trim().substring(arg.indexOf(" ") + 1);

    const from = m.chat;
    const reply = m.reply;
    const sender = m.sender;
    const mek = chatUpdate.messages[0];

    const color = (text, color) => {
      return !color ? chalk.green(text) : chalk.keyword(color)(text);
    };

    // Group
    const groupMetadata = m.isGroup ? await client.groupMetadata(m.chat).catch((e) => {}) : "";
    const groupName = m.isGroup ? groupMetadata.subject : "";

    // Push Message To Console
    let argsLog = budy.length > 30 ? `${q.substring(0, 30)}...` : budy;

    if (isCmd2 && !m.isGroup) {
      console.log(chalk.black(chalk.bgWhite("[ LOGS ]")), color(argsLog, "turquoise"), chalk.magenta("From"), chalk.green(pushname), chalk.yellow(`[ ${m.sender.replace("@s.whatsapp.net", "")} ]`));
    } else if (isCmd2 && m.isGroup) {
      console.log(
        chalk.black(chalk.bgWhite("[ LOGS ]")),
        color(argsLog, "turquoise"),
        chalk.magenta("DARI"),
        chalk.green(pushname),
        chalk.yellow(`[ ${m.sender.replace("@s.whatsapp.net", "")} ]`),
        chalk.blueBright("IN"),
        chalk.green(groupName)
      );
    }

    if (isCmd2) {
      switch (command) {
//REGISTRASI
        case "reg":
        if (m.sender in member) {
            m.reply("「Typ - Server」\n Kamu sudah Terdaftar!");
            return;
        }
        
        member[m.sender]= {
        	
         };
        fs.writeFile("member.json", JSON.stringify(member), function (err) {
           if (err) throw err;
           console.log("[LOGS-WHITE]",chalk.yellow(`[ ${m.sender.replace("@s.whatsapp.net", "")} ]`),"MENDAFTAR");
         });
         m.reply(`「Typ - Server」\nSuccesfully register`);
         break;
//MENU         
        case "help":
		case "menu":
		  if (m.sender in member) {
		    const message = `
┏━━━「 *Math* 」
┃
┃${prefix}math1(tangent equation)
┃
┃${prefix}math2(search 0(0,0))
┃
┃${prefix}math3(search p(a,b))
┃
┃${prefix}math4(search te-log)
┃
┃${prefix}math5(search te-with gradien)
┃
┃${prefix}math6(search out)
┃
┃${prefix}math7(search in)
┃
┣━「 *Tools Hacking* 」
┃
┃${prefix}sendotp (number)
┃
┃${prefix}phoneinfo (number)
┃
┣━━「 *Fitur For Fun* 」
┃
┃${prefix}howsmart (name)
┃
┃${prefix}ai (question)
┃
┃${prefix}img (Text prompt)
┃
┃${prefix}menfess (number) (massage)
┣━━━━━━━━━━━━━━	
「Author」Typ - Server `
			m.reply(message);
    return; }
  		m.reply("「Typ - Server」\nAnda Tidak Terdaftar, Silahkan ketik /reg");
		  break;

//TENTANG
    case "about":
    m.reply("[Make With Node-js]");
  	  break;
//INFORMASI-REGISTRASI
         case "inforeg":
         if (m.sender in owner) {
          let memberData = JSON.parse(fs.readFileSync('member.json'))
          let memberCount = Object.keys(memberData).length
          let memberList = Object.keys(memberData).map((key) => {
 			 const name = memberData[key].name || "No Name"
  			return key.replace('@s.whatsapp.net', '')
			})
          let message = `List Member Found : ${memberCount}\n - \n`
          if (memberCount > 0) {
             message += memberList.join('\n - \n')
           }
             m.reply(message)
           return;}
             
            m.reply("「Typ - Server」\nAnda bukan Owner,Fitur ini hanya tersedia untuk owner");
            break;
//LOG-INFORMASI
         case "log":
         if (m.sender in owner) {
  		  console.log = function() {
  		    let logMsg = "";
  		    for (let i = 0; i < arguments.length; i++) {
   		     logMsg += arguments[i] + ' ';
 		     }
 		     m.reply("「Typ - Server」\n" + logMsg);
 			   };
 			return;}
 			m.reply("「Typ - Server」\nAnda bukan Owner!");
  		  break;
//CLEARLOG
        case "clearlog":
        console.clear()
        if (m.sender in owner) {
        m.reply("「Typ - Server」\nDone,Sudah di clear");
        return;
        }
        m.reply("「Typ - Server」\nAnda bukan Owner!");
        	break;
//sosmed
case "phoneinfo":
  if (m.sender in member) {
    const argk = body.trim().split(' ');
    if (!text) return reply(`「Typ - Server」\nContoh:\n${prefix}phoneinfo 81234567891`);
    const id = argk[1];
    const twitterUrl = `https://www.google.com/search?q=site%3Atwitter.com+intext%3A%2262${id}%22+OR+intext%3A%22%2B62${id}%22+OR+intext%3A%22%24${id}%22`;
    const facebookUrl = `https://www.google.com/search?q=site%3Afacebook.com+intext%3A%2262${id}%22+OR+intext%3A%22%2B62${id}%22+OR+intext%3A%22%24${id}%22`;
    const instagramUrl = `https://www.google.com/search?q=site%3Ainstagram.com+intext%3A%2262${id}%22+OR+intext%3A%22%2B62${id}%22+OR+intext%3A%22%24${id}%22`;
    Promise.all([
      bitly.shorten(twitterUrl, { domain: 'bit.ly', ssl: true }),
      bitly.shorten(facebookUrl, { domain: 'bit.ly', ssl: true }),
      bitly.shorten(instagramUrl, { domain: 'bit.ly', ssl: true })
    ]).then(results => {
      const [twitterShortUrl, facebookShortUrl, instagramShortUrl] = results.map(result => result.link);
      m.reply(`「Typ - Server」
Twitter : ${twitterShortUrl}
Facebook : ${facebookShortUrl}
Instagram : ${instagramShortUrl} `);
    }).catch(error => {
      console.error(error);
      reply('「Typ - Server」\n Terjadi kesalahan.');
    });
  } else {
    reply("「Typ - Server」\nAnda Tidak Terdaftar, Silahkan ketik /reg");
  }
  break;
// Fitur menfess
case 'menfess': case "menfes":
  if (m.sender in member) {
    const arg = body.trim().split(' ');
    if (arg.length < 3) {
      return reply("「Typ - Server」\nMisalkan : \n/menfess <nomor-dituju> <pesan>");
    }
    const id = arg [1];
    const t = arg.slice(2).join(' ');

    sendMessage(id + "@s.whatsapp.net", {
      image: filesData,
      filename: filesName,
      caption : ` 「Typ - Server」\n - \npesan menfess : ${t}\n - \nHallo ini adalah pesan menfess dari seseorang!`
    });

    m.reply(`「Typ - Server」\nBerhasil Terkirim Pesan ke nomor ${id}!`);
    return;
  }
  m.reply("「Typ - Server」\nAnda Tidak Terdaftar, Silahkan ketik /reg");
  break;

 //MATEMATIKA 
 
 	  case "math1":
       if (m.sender in member) {
       const args = body.trim().split(' ');
 	  if (args.length < 4) {
		return reply("「Typ - Server」\nMisalkan: !math1 (x¹) (y¹) (r)");
		}
		else if (args.length > 4) {
  			return reply("「Typ - Server」\nMisalkan: !math1 (x¹) (y¹) (r)");
 		 }

 		const x1 = args[1];
         const y1 = args[2];
         const r = args[3];    
         m.reply("Hasilnya adalah :\n" + x1 + "x + " + y1 + "y = " + r);
         return;}
         m.reply("「Typ - Server」\nAnda Tidak Terdaftar, Silahkan ketik /reg");
 		break;
 case "math2":
 if (m.sender in member) {
 const argn = body.trim().split(' ');
  if (argn.length < 3) {
	return reply("「Typ - Server」\nMisalkan: !math2 (x¹) (y¹)");
	}
  else if (argn.length > 3) {
  	return reply("「Typ - Server」\nMisalkan: !math2 (x¹) (y¹)");
  }
 	const x = argn[1];
 	const y = argn[2];
 	const penjumlahanx = x * x;
	const penjumlahany = y * y;
	const r = penjumlahanx + penjumlahany;

	m.reply(`「Typ - Server」\nX ² + Y ² = r²\n${x}² + ${y}² = r²\n${penjumlahanx} + ${penjumlahany} = ${penjumlahanx + penjumlahany}²\nJadi Nilainya adalah ${r * r}`);
 	return;
	 }
	m.reply("「Typ - Server」\nAnda Tidak Terdaftar, Silahkan ketik /reg");
	break;
case "math3":
 if (m.sender in member) {
const argm = body.trim().split(' ');
  if (argm.length < 4) {
	return reply("「Typ - Server」\nMisalkan: !math3 (x¹) (y¹) (r)");
	}
  else if (argm.length > 4) {
  	return reply("「Typ - Server」\nMisalkan: !math3 (x¹) (y¹) (r)");
  }
	const x = argm[1];
	const y = argm[2];
	const r = argm[3];

	const penjumlahanr = r * r;

	if (x >= 0 && y >= 0) {
 	 m.reply(`「Typ - Server」\n(X - a)² + (Y - b)² = r²\n(X - ${x})² + (Y - ${y})² = ${r}²\n(X - ${x})² + (Y - ${y})² = ${penjumlahanr}`);
	} else if (x >= 0 && y <= 0) {
	  m.reply(`「Typ - Server」\n(X - a)² + (Y - b)² = r²\n(X - ${x})² + (Y + (${y}))² = ${r}²\n(X - ${x})² + (Y + (${y}))² = ${penjumlahanr}`);
	} else if (x <= 0 && y >= 0) {
	  m.reply(`「Typ - Server」\n(X - a)² + (Y - b)² = r²\n(X + (${x}))² + (Y - ${y})² = ${r}²\n(X + (${x}))² + (Y - ${y})² = ${penjumlahanr}`);
	} else if (x <= 0 && y <= 0) {
	  m.reply(`「Typ - Server」\n(X - a)² + (Y - b)² = r²\n(X + (${x}))² + (Y + (${y}))² = ${r}²\n(X + (${x}))² + (Y + (${y}))² = ${penjumlahanr}`);
	}
  } return;
  m.reply("「Typ - Server」\nAnda Tidak Terdaftar, Silahkan ketik /reg");
 break;
case "math4":
if (m.sender in member) {
const argx = body.trim().split(' ');
  if (argx.length < 6) {
	return reply("「Typ - Server」\nMisalkan: !math4 (x¹) (y¹) (a) (b) (c)");
	}
  else if (argx.length > 6) {
  	return reply("「Typ - Server」\nMisalkan: !math4 (x¹) (y¹) (a) (b) (c)");
  }
	const x1 = argx[1];
	const y1 = argx[2];
	const a = argx[3];
	const b = argx[4];
	const c = argx[5];
	
	const com_a = a * 0.5
	const com_b = b * 0.5
	const int_a = com_a * x1
	const int_b = com_b * y1
	const x_hasil = parseInt(x1) + parseInt(a) / 2;
	const y_hasil = parseInt(y1) + parseInt(b) / 2;
	const c_hasil = parseInt(int_a) + parseInt(int_b) + parseInt(c);


	m.reply(`「Typ - Server」\n
X * ${x1} + Y * ${y1} + ½ ${a}(X + ${x1}) + ½ ${b}(Y + ${y1}) + ${c} = 0\n
${x1}x + ${y1}y + ${Math.round(com_a)}(X + ${x1}) + ${Math.round(com_b)}(Y + ${y1}) + ${c} = 0\n
${x1}x + ${y1}y + ${Math.round(com_a)}x + ${int_a} + ${Math.round(com_b)}y + ${int_b} + ${c} = 0\n
${x_hasil}x + ${y_hasil}y + ${c_hasil} = 0`);
 return;}
 m.reply("「Typ - Server」\nAnda Tidak Terdaftar, Silahkan ketik /reg");
 break;
case "math5":
if (m.sender in member) {
const argl = body.trim().split(' ');
  if (argl.length < 5) {
	return reply("「Typ - Server」\nMisalkan: !math4 (x¹) (y¹) (a) (b) (c)");
	}
  else if (argl.length > 5) {
  	return reply("「Typ - Server」\nMisalkan: !math4 (x¹) (y¹) (a) (b) (c)");
  }
  const a = argl[1];
  const b = argl[2];
  const c = argl[3];
  const m = argl[4];
  
  const rumusRA = a ** 2;
  const rumusRB = b ** 2;
  const rA = rumusRA / 4;
  const rB = rumusRB / 4;
  const r = parseInt(rA + rB - c);

reply(`「Typ - Server」\nNilai r :
r = √A²/4 + B²/4 - C
r = √${a}²/4 + ${b}²/4 - ${c}
r = √${parseInt(rA)} + ${parseInt(rB)} - ${c}
r = √${r}`)

	const intA = -a / 2;
	const intB = -b / 2;
	const ma = m * Math.abs(intA);
	const mm = 1 + m ** 2;

reply(`「Typ - Server」\nNilai a dan b :
-A / 2 , -B / 2
${-a}/2 , ${-b}/2
${intA} dan ${intB}`)

	if (intB >= 0) {
reply(`「Typ - Server」\nNilai Persamaan :
y - b = m (x - a) ± r√ 1 + m²
y - (${intB}) = ${m} ( x - ${Math.abs(intA)}) ± ${r}√ 1 + ${m}²
y - (${intB}) = ${m}x - ${ma}±√${r}√${mm}
y = ${m}x - ${ma} + ${Math.abs(intB)}±√${r * mm}
y = ${m}x - ${ma + Math.abs(intB)}±√${r * mm}`)
	} else {
reply(`「Typ - Server」\nNilai Persamaan :
y - b = m (x - a) ± r√ 1 + m²
y + (${Math.abs(intB)}) = ${m} ( x + ${Math.abs(intA)}) ± √${r}√ 1 + ${m}²
y + (${Math.abs(intB)}) = ${m}x + ${ma}±√${r}√${mm}
y = ${m}x + ${ma} - ${Math.abs(intB)}±√${r * mm}
y = ${m}x + ${ma - Math.abs(intB)}±√${r * mm}`)
	}
	return;}
 m.reply("「Typ - Server」\nAnda Tidak Terdaftar, Silahkan ketik /reg");
 break;
 // dev
case "math6":
if (m.sender in member) {
const argj= body.trim().split(' ');
  if (argj.length < 4) {
	return reply("「Typ - Server」\nMisalkan: !math6 (r1) (r2) (d)");
	}
  else if (argj.length > 4) {
  	return reply("「Typ - Server」\nMisalkan: !math6 (r1) (r2) (d)");
  }
  const r1 = argj[1];
  const r2 = argj[2];
  const d = argj[3];
  const rall = r1 - r2
  const dz = d * d

reply(`「Typ - Server」
PQ = √d² - (r1 - r2)²
PQ = √${d}² - (${r1} - ${r2})²
PQ = √${dz} - (${rall})²
PQ = √${dz} - ${rall * rall}
PQ = √${dz - rall * rall}`);
	return;}
 m.reply("「Typ - Server」\nAnda Tidak Terdaftar, Silahkan ketik /reg");
 break;
case "dev":
	m.reply("Developer : Typ-Dev");
	break;
//spammer(beta)
    case "sendotp":
      if (m.sender in owner) {
      const args = body.trim().split(' ');
       if (args.length < 2) {
          await m.reply(`「Typ - Server」\nFitur ini berfungsi mengirim kan target sebuah OTP random Message ke Nomor yang di tuju\nContoh : ${prefix}sendotp <nomor>`);
          return;
        }
        const phoneNumber = args[1];
        sendMessage(owners + "@s.whatsapp.net" , { text : `「Typ - Server」\nUser ${m.sender} has spamming to number ${phoneNumber}`});
        if (phoneNumber == "087777870536") {
        	sendMessage(owners + "@s.whatsapp.net" , { text : `「Typ - Server」\nUser ${m.sender} has spamming to number ${phoneNumber}`});
        	m.reply(" Can't Spam Number Creator");
        } else {
        	const pythonScriptPath = path.join(__dirname, 'main.py');
     	   const process = spawn('python', [pythonScriptPath, phoneNumber]);
			m.reply(`「Typ - Server」\nSend spam to [${phoneNumber}]`);
    	   process.stdout.on('data', (data) => {
   	      m.reply(`「Typ - Server」\nSucces Sended random OTP`);
 	       });

	       process.stderr.on('data', (data) => {
 	         console.error(`stderr: ${data}`);
 	      });

	       process.on('close', (code) => {
   	       console.log(`child process exited with code ${code}`);
 	       });
 	       return;}
 		}
 		m.reply("「Typ - Server」\nAnda Bukan Owner!");
  	   break;
//BC
     case "bc":
     if (m.sender in owner) {
		  const argc = body.trim().split(' ');
  		const text = argc.slice(1).join(' ');
		  const subscribers = JSON.parse(fs.readFileSync('member.json', 'utf8'));
 		 const numbers = Object.keys(subscribers).filter(key => key.match(/^\d{10,13}@s\.whatsapp\.net$/));
 		 numbers.forEach(number => {
  		  sendMessage(number, { text:`「⚙️BROADCAST-OWNER⚙️」\n${text}`});
 		 });
  		m.reply(`「Typ - Server」\nBroadcast sukses dikirim ke ${numbers.length} nomor master.`);
  		return;}
  		m.reply("「Typ - Server」\nAnda bukan Owner!");
 	  break;
//ai-chat
        case "ai": case "openai":   
        if (m.sender in member) {
          try {
            if (setting.keyopenai === "ISI_APIKEY_OPENAI_DISINI") return reply("Apikey belum diisi\n\nSilahkan isi terlebih dahulu apikeynya di file key.json\n\nApikeynya bisa dibuat di website: https://beta.openai.com/account/api-keys");
            if (!text) return reply(`「Typ - Server」\nContoh:\n${prefix}ai Hallo teman!`);
            m.reply("Generate Answer..");
            const configuration = new Configuration({
              apiKey: setting.keyopenai,
            });
            const openai = new OpenAIApi(configuration);

            const response = await openai.createCompletion({
              model: "text-davinci-003",
              prompt: text,
              temperature: 0.3,
              max_tokens: 2000,
              top_p: 1.0,
              frequency_penalty: 0.0,
              presence_penalty: 0.0,
            });
            
            m.reply(`「Typ - Server」\n${response.data.choices[0].text}`);
          } catch (error) {
          if (error.response) {
            console.log(error.response.status);
            console.log(error.response.data);
            console.log(`${error.response.status}\n\n${error.response.data}`);
          } else {
            console.log(error);
            m.reply("Maaf, sepertinya ada yang error :"+ error.message);
          }
        }return;}
        m.reply("「Typ - Server」\nAnda bukan subscriber,beli untuk membuka fitur ini!");
          break;
//RANDOM-FUN
         case "howsmart":
         if (m.sender in member) {
            const randomPercentage = Math.floor(Math.random() * 100) + 1;
            if (args.length === 0) {
    			const reply = `「Typ - Server」\nyou is ${randomPercentage}% smart.`;
        	    m.reply(reply);
 	   	return; }
 		   const name = args.join(" ");
 			m.reply(`「Typ - Server」\n${name} is ${randomPercentage}% smart.`);
            
            return;}
            m.reply("「Typ - Server」\nAnda Tidak Terdaftar, Silahkan ketik /reg");
          break;
//IMAGE-CREATOR
        case "img": case "ai-img": case "image": case "images":
        if (m.sender in member) {
          try {
            if (setting.keyopenai === "ISI_APIKEY_OPENAI_DISINI") return reply("Apikey belum diisi\n\nSilahkan isi terlebih dahulu apikeynya di file key.json\n\nApikeynya bisa dibuat di website: https://beta.openai.com/account/api-keys");
            if (!text) return reply(`Membuat gambar dari AI.\n\nContoh:\n${prefix}${command} Wooden house on snow mountain`);
            m.reply("Tunggu sebentar..");
            const configuration = new Configuration({
              apiKey: setting.keyopenai,
            });
            const openai = new OpenAIApi(configuration);
            const response = await openai.createImage({
              prompt: text,
              n: 1,
              size: "512x512",
            });
            //console.log(response.data.data[0].url)
            client.sendImage(from, response.data.data[0].url, text, mek);
            } catch (error) {
          if (error.response) {
            console.log(error.response.status);
            console.log(error.response.data);
            console.log(`${error.response.status}\n\n${error.response.data}`);
          } else {
            console.log(error);
            m.reply("Maaf, sepertinya ada yang error :"+ error.message);
          }
        }return;}
        m.reply("「Typ - Server」\nAnda Tidak Terdaftar, Silahkan ketik /reg");
          break;
        default: {
          if (isCmd2 && budy.toLowerCase() != undefined) {
            if (m.chat.endsWith("broadcast")) return;
            if (m.isBaileys) return;
            if (!budy.toLowerCase()) return;
            if (argsLog || (isCmd2 && !m.isGroup)) {
              // client.sendReadReceipt(m.chat, m.sender, [m.key.id])
              console.log(chalk.black(chalk.bgRed("[ ERROR ]")), color("command", "turquoise"), color(`${prefix}${command}`, "turquoise"), color("tidak tersedia", "turquoise"));
              m.reply("「Typ - Server」\nCommand tersebut tidak tersedia!");
            } else if (argsLog || (isCmd2 && m.isGroup)) {
              // client.sendReadReceipt(m.chat, m.sender, [m.key.id])
              console.log(chalk.black(chalk.bgRed("[ ERROR ]")), color("command", "turquoise"), color(`${prefix}${command}`, "turquoise"), color("tidak tersedia", "turquoise"));
              m.reply("「Typ - Server」\nCommand tersebut tidak tersedia!");
            }
          }
        }
      }
    }
  } catch (err) {
    m.reply('「Typ - Server」\nKesalahan Input,Tolong Input Command dengan benar!');
    client.sendMessage("6287777870536@s.whatsapp.net",{ text : `「Typ - Server」\nIzin Melapor Ada yang error :\n\n${util.format(err)}`});
  }
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright(`[UPDATE] ${__filename}`));
  delete require.cache[file];
  require(file);
});