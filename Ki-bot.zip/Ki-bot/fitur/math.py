import os
os.system('clear')
print('''----     ----     ----  MENU  ----     ----     ----  

[1] MENCARI (R) DENGAN TITIK PUSAT 0(0,0)

[2] MENCARI (R) DENGAN TITIK PUSAT P(a,b)

[3] MENENTUKAN PERSAMAAN GARIS SINGGUNG 

[4] MENENTUKAN PERSAMAAN GARIS SINGGUNG DENGAN GRADIEN

[5] MENENTUKAM PANJANG GARIS SINGGUNG(PERSEKETUAN LUAR)
----      ----       ----     ----     ----     ----     ''')

choose = input("PILIH MENU : ")

if choose == "1":
	os.system('clear')
	print("SOAL PERSAMAAN LINGKARAN DENGAN TITIK 	PUSAT 0(0,0)")
	x = int(input("[×]Nilai X : "))
	y = int(input("[×]Nilai Y : "))

	penjumlahanx = x * x 
	penjumlahany = y * y
	os.system('clear')
	print("----- Nilai Persamaan -----")
	print("X ² + Y ² = r²")
	 
	print(x,"² + " , y,"²", "= r²")
	 
	print(penjumlahanx , "+", penjumlahany, "=",penjumlahanx + penjumlahany ,("²"))
	print("--------------------------")
elif choose == "2":
	os.system('clear')
	print("SOAL PERSAMAAN LINGKARAN DENGAN TITIK 	PUSAT P(a,b)")
	x = int(input("[×]Nilai X : "))
	y = int(input("[×]Nilai Y : "))
	r = int(input("[×]Nilai R : "))

	penjumlahanr = r * r
	os.system('clear')
	#apabila semua positif
	if x >= 0 and y >= 0:
	    print("----- Nilai Persamaan -----")
	    print("(X - a)² + (Y - b)² = r")
		 
	    print("(X -" ,x, ")² +","(Y -",y,")²","=",r, "²")
		 
	    print("(X -" ,x, ")² +","(Y -",y,")²","=", penjumlahanr)
	    print("--------------------------")
	#apabila y negatif
	elif x >= 0 and y <= 0:
	    print("----- Nilai Persamaan -----")
	    print("(X - a)² + (Y - b)² = R")    
		 
	    print("(X -" ,x, ")² +","(Y +","(",y ,")" ,")²","=",r, "²")
		 
	    print("(X -" ,x, ")² +","(Y +","(",y ,")",")²","=", penjumlahanr)
	    print("--------------------------")
	#apabila x negatif
	elif x <= 0 and y >= 0:
	    print("----- Nilai Persamaan -----")
	    print("(X - a)² + (Y - b)² = R")    
		 
	    print("(X +" ,"(",x ,")", ")² +","(Y -",y ,")²","=",r, "²")
		 
	    print("(X +" ,"(",x ,")", ")² +","(Y -",y ,")²","=", penjumlahanr)
	    print("--------------------------")
	#apabila semua negatif
	elif x <= 0 and y <= 0:
	    print("----- Nilai Persamaan -----")
	    print("(X - a)² + (Y - b)² = R")    
		 
	    print("(X +" ,"(",x ,")", ")² +","(Y +","(",y ,")" ,")²","=",r, "²")
		 
	    print("(X +" ,"(",x ,")", ")² +","(Y +","(",y ,")" ,")²","=", penjumlahanr)
	    print("--------------------------")
elif choose == "3":
	os.system('clear')
	print("SOAL MENENTUKAN PERSAMAAN GARIS SINGGUNG")	
	
	x1 = int(input("[×]Nilai x¹ : "))
	y1  = int(input("[×]Nilai y¹ : "))
	a = int(input("[×]Nilai a : "))
	b  = int(input("[×]Nilai b : "))
	c = int(input("[×]Nilai c : "))
	
	com_x1 = str(x1) + "x"
	com_y1 = str(y1) + "y"
	com_a = a * 0.5
	com_b = b * 0.5
	comb_newb = f"{com_b:.0f}y"
	comb_newa = f"{com_a:.0f}x"
	int_a = int(com_a * x1)
	int_b = int(com_b * y1)
	x_hasil = x1 + com_a
	y_hasil = y1 + com_b
	c_hasil = int_a + int_b + c
	
	os.system('clear')
	print("----- Nilai Persamaan -----")
	print("X * X¹ + Y * Y¹ + ½ a(X + X¹) + ½ b(Y + Y¹) + c = r")
	 
	print("X *",x1,"+ Y *",y1,"+ ½",a,"(X +",x1,") + ½",b,"(Y +",y1, ") +",c,"= 0")
	 
	print(com_x1,"+",com_y1,"+",int(com_a),"(X +",x1,") +",int(com_b),"(Y +",y1,")","+",c,"= 0")
	 
	print(com_x1,"+",com_y1,"+",comb_newa , "+",int_a,"+",comb_newb,"+",int_b,"+",c,"= 0")
	 
	print(int(x_hasil),"x +",int(y_hasil),"y +",c_hasil,"= 0")
	print("--------------------------")
elif choose == "4":
	os.system('clear')
	print("SOAL PERSAMAAN GARIS SINGGUNG DENGAN GRADIEN")
	A = int(input("[×]Nilai A : "))
	B = int(input("[×]Nilai B : "))
	C = int(input("[×]Nilai C: "))
	m = int(input("[×]Nilai Gradien : "))
	os.system('clear')
	
	rumus_r_A = A * A 
	rumus_r_B = B * B
	r_a = rumus_r_A / 4
	r_b = rumus_r_B / 4
	r = int(r_a + r_b - C)
	print("------- Nilai r ------")
	print("r = √A²/4 + B²/4 - C")
	 
	print("r = √",A,"²/4 +",B,"²/4 -",C)
	 
	print("r = √",int(r_a),"+",int(r_b),"-",C)
	 
	print("r = √",r)
	print("-----------------------")
	print("                              ")
	
	a = int(-A / 2)
	b = int(-B / 2)
	m_a = m * int(abs(a))
	m_m = 1 + m * m
	
	print("--- Nilai a dan b ---")
	print("-A / 2 , -B / 2")
	 
	print(-A,"/2 ,",-B,"/ 2")
	 
	print(a,"dan",b)
	print("------------------------")
	print("                             ")
	
	if b >= 0:
		print("----- Nilai Persamaan -----")
		print("y - b = m (x - a) ± r√ 1 + m²")
		 
		print("y - (",b,") =",m,"( x -",int(abs(a)),") ±",r,"√ 1","+ " + str(m) + "²")
		 
		print("y -","(",b,") =",str(m) + "x -",m_a,"±","√",r,"√",m_m)
		 
		print("y =",str(m) + "x -",m_a,"+",int(abs(b)),"±","√",r * m_m)
		 
		print("y =",str(m) + "x -",m_a + int(abs(b)),"± √", r * m_m)
		print("------------------------")
	elif b <= 0:
		print("----- Nilai Persamaan -----")
		print("y - b = m (x - a) ± r√ 1 + m²")
		 
		print("y + (",b,") =",m,"( x +",int(abs(a)),") ±",r,"√ 1","+ " + str(m) + "²")
		 
		print("y +","(",b,") =",str(m) + "x +",m_a,"±","√",r,"√",m_m)
		 
		print("y =",str(m) + "x +",m_a,"-",int(abs(b)),"±","√",r * m_m)
		 
		print("y =",str(m) + "x +",m_a - int(abs(b)),"± √", r * m_m)
		print("------------------------")
	else:
		print("Error!")
elif choose == "5":
		os.system('clear')
		print("SOAL MENENTUKAM PANJANG GARIS SINGGUNG(PERSEKETUAN LUAR)")
		
		r1 = int(input("[×]Nilai r1 : "))
		r2 = int(input("[×]Nilai r2 : "))
		d = int(input("[×]Nilai d(titik pusat) : "))
		rall = r1 - r2
		dz = d * d
		os.system('clear')
		print(" ---- Nilai Persekutuan Luar --- ")
		print("PQ = √d² - (r1 - r2)²")
		 
		print("PQ = √",d,"² - (",r1,"-",r2,")²")
		 
		print("PQ = √",dz,"-","(",rall,")²")
		 
		print("PQ = √",dz,"-",rall * rall)
		 
		print("PQ = √",dz - rall * rall)
		print("------------------")
		
	
else:
	print("Salah Goblog!")
